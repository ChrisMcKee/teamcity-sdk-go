package jetbrains.buildServer.configs.kotlin.buildSteps

import jetbrains.buildServer.configs.kotlin.*

/**
 * A [dotnet nuget push step](https://github.com/JetBrains/teamcity-dotnet-plugin) to run .NET CLI command
 *
 * **Example.**
 * Runs [`dotnet nuget push`](https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-nuget-push) command to push and publish specified packages to a specified server
 * ```
 * dotnetNugetPush {
 *     packages = "*.nupkg"
 *     serverUrl = "https://nuget.example.com/feed"
 *     apiKey = "******"
 * }
 * ```
 *
 *
 * @see dotnetNugetPush
 */
open class DotnetNugetPushStep() : BuildStep() {

    init {
        type = "dotnet"
        param("command", "nuget-push")
    }

    constructor(init: DotnetNugetPushStep.() -> Unit): this() {
        init()
    }

    /**
     * Specify paths to nuget packages. Wildcards are supported.
     */
    var packages by stringParameter("paths")

    /**
     * Specify the server URL. To use a TeamCity NuGet feed, specify the URL from the NuGet feed project settings page.
     */
    var serverUrl by stringParameter("nuget.packageSource")

    /**
     * Specify the API key to access the NuGet packages feed.
     * For the built-in TeamCity NuGet server use %teamcity.nuget.feed.api.key%.
     */
    var apiKey by stringParameter("secure:nuget.apiKey")

    /**
     * Do not publish nuget symbol packages
     */
    var noSymbols by booleanParameter("nuget.noSymbols", trueValue = "true", falseValue = "")

    /**
     * Enter additional command line parameters for dotnet nuget push.
     */
    var args by stringParameter()

    /**
     * Specify logging verbosity
     *
     *
     * @see Verbosity
     */
    var logging by enumParameter<Verbosity>("verbosity")

    /**
     * .NET SDK versions separated by semicolon to be required on agents.
     */
    var sdk by stringParameter("required.sdk")

    /**
     * Specifies which Docker image to use for running this build step. I.e. the build step will be run inside specified docker image, using 'docker run' wrapper.
     */
    var dockerImage by stringParameter("plugin.docker.imageId")

    /**
     * Specifies which Docker image platform will be used to run this build step.
     */
    var dockerImagePlatform by enumParameter<ImagePlatform>("plugin.docker.imagePlatform", mapping = ImagePlatform.mapping)

    /**
     * If enabled, "pull [image][dockerImage]" command will be run before docker run.
     */
    var dockerPull by booleanParameter("plugin.docker.pull.enabled", trueValue = "true", falseValue = "")

    /**
     * Additional docker run command arguments
     */
    var dockerRunParameters by stringParameter("plugin.docker.run.parameters")

    /**
     * Logging verbosity
     */
    enum class Verbosity {
        Quiet,
        Minimal,
        Normal,
        Detailed,
        Diagnostic;

    }
    /**
     * Docker image platforms
     */
    enum class ImagePlatform {
        Any,
        Linux,
        Windows;

        companion object {
            val mapping = mapOf<ImagePlatform, String>(Any to "", Linux to "linux", Windows to "windows")
        }

    }
    override fun validate(consumer: ErrorConsumer) {
        super.validate(consumer)
        if (packages == null && !hasParam("paths")) {
            consumer.consumePropertyError("packages", "mandatory 'packages' property is not specified")
        }
        if (serverUrl == null && !hasParam("nuget.packageSource")) {
            consumer.consumePropertyError("serverUrl", "mandatory 'serverUrl' property is not specified")
        }
        if (apiKey == null && !hasParam("secure:nuget.apiKey")) {
            consumer.consumePropertyError("apiKey", "mandatory 'apiKey' property is not specified")
        }
    }
}


/**
 * Adds a [dotnet nuget push step](https://github.com/JetBrains/teamcity-dotnet-plugin) to run .NET CLI command
 *
 * **Example.**
 * Runs [`dotnet nuget push`](https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-nuget-push) command to push and publish specified packages to a specified server
 * ```
 * dotnetNugetPush {
 *     packages = "*.nupkg"
 *     serverUrl = "https://nuget.example.com/feed"
 *     apiKey = "******"
 * }
 * ```
 *
 *
 * @see DotnetNugetPushStep
 */
fun BuildSteps.dotnetNugetPush(init: DotnetNugetPushStep.() -> Unit): DotnetNugetPushStep {
    val result = DotnetNugetPushStep(init)
    step(result)
    return result
}
