package jetbrains.buildServer.configs.kotlin.buildSteps

import jetbrains.buildServer.configs.kotlin.*

/**
 * A [dotnet build step](https://github.com/JetBrains/teamcity-dotnet-plugin) to run a custom command
 *
 * **Example.**
 * Runs [`dotnet EXECUTABLE`](https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet#options-for-running-an-application) to run specified .NET application
 * ```
 * dotnetCustom {
 *     executables = "MyProgram.exe"
 *     args = "abc=123"
 * }
 * ```
 *
 *
 * @see dotnetCustom
 */
open class DotnetCustomStep() : BuildStep() {

    init {
        type = "dotnet"
        param("command", "custom")
    }

    constructor(init: DotnetCustomStep.() -> Unit): this() {
        init()
    }

    /**
     * Specify paths Specify paths to executable files. Wildcards are supported.
     */
    var executables by stringParameter("paths")

    /**
     * [Working directory](https://www.jetbrains.com/help/teamcity/?Build+Working+Directory) for
     * executables,
     * specify it if it is different from the [checkout
     * directory](https://www.jetbrains.com/help/teamcity/?Build+Checkout+Directory).
     */
    var workingDir by stringParameter("teamcity.build.workingDir")

    /**
     * Enter additional command line parameters for custom command.
     */
    var args by stringParameter()

    /**
     * .NET SDK versions separated by semicolon to be required on agents.
     */
    var sdk by stringParameter("required.sdk")

    /**
     * Specifies coverage tool to use
     */
    var coverage by compoundParameter<Coverage>("dotNetCoverage.tool")

    sealed class Coverage(value: String? = null): CompoundParam<Coverage>(value) {
        class Dotcover() : Coverage("dotcover") {

            /**
             * Specify the path to dotCover CLT.
             */
            var toolPath by stringParameter("dotNetCoverage.dotCover.home.path")

            /**
             * Specify a new-line separated list of filters for code coverage.
             */
            var assemblyFilters by stringParameter("dotNetCoverage.dotCover.filters")

            /**
             * Specify a new-line separated list of attribute filters for code coverage.
             * Supported only with dotCover 2.0 or later.
             */
            var attributeFilters by stringParameter("dotNetCoverage.dotCover.attributeFilters")

            /**
             * Enter additional new-line separated command line parameters for dotCover.
             */
            var args by stringParameter("dotNetCoverage.dotCover.customCmd")

        }
    }

    fun dotcover(init: Coverage.Dotcover.() -> Unit = {}) : Coverage.Dotcover {
        val result = Coverage.Dotcover()
        result.init()
        return result
    }

    /**
     * Specifies which Docker image to use for running this build step. I.e. the build step will be run inside specified docker image, using 'docker run' wrapper.
     */
    var dockerImage by stringParameter("plugin.docker.imageId")

    /**
     * Specifies which Docker image platform will be used to run this build step.
     */
    var dockerImagePlatform by enumParameter<ImagePlatform>("plugin.docker.imagePlatform", mapping = ImagePlatform.mapping)

    /**
     * If enabled, "pull [image][dockerImage]" command will be run before docker run.
     */
    var dockerPull by booleanParameter("plugin.docker.pull.enabled", trueValue = "true", falseValue = "")

    /**
     * Additional docker run command arguments
     */
    var dockerRunParameters by stringParameter("plugin.docker.run.parameters")

    /**
     * Docker image platforms
     */
    enum class ImagePlatform {
        Any,
        Linux,
        Windows;

        companion object {
            val mapping = mapOf<ImagePlatform, String>(Any to "", Linux to "linux", Windows to "windows")
        }

    }
    override fun validate(consumer: ErrorConsumer) {
        super.validate(consumer)
    }
}


/**
 * Adds a [dotnet build step](https://github.com/JetBrains/teamcity-dotnet-plugin) to run a custom command
 *
 * **Example.**
 * Runs [`dotnet EXECUTABLE`](https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet#options-for-running-an-application) to run specified .NET application
 * ```
 * dotnetCustom {
 *     executables = "MyProgram.exe"
 *     args = "abc=123"
 * }
 * ```
 *
 *
 * @see DotnetCustomStep
 */
fun BuildSteps.dotnetCustom(init: DotnetCustomStep.() -> Unit): DotnetCustomStep {
    val result = DotnetCustomStep(init)
    step(result)
    return result
}
