package jetbrains.buildServer.configs.kotlin.v2017_2.projectFeatures

import jetbrains.buildServer.configs.kotlin.v2017_2.*

/**
 * Project feature defining an OAuth connection settings for GitHub Enterprise server
 *
 * **Example.**
 * It is not recommended to store secure values such as the secret directly in the DSL code,
 * see [Managing Tokens](https://www.jetbrains.com/help/teamcity/storing-project-settings-in-version-control.html#Managing+Tokens)
 * section of our documentation.
 * ```
 * gheConnection {
 *   id = "<Connection id>" // arbitrary ID that can be later used to refer to the connection
 *   displayName = "<Connection display name>"
 *   serverUrl = "<GitHub Enterprise server URL>"
 *   clientId = "<OAuth2 application client ID>"
 *   clientSecret = "credentialsJSON:*****"
 *   useUniqueCallback = true // optional, false by default
 * }
 * ```
 *
 *
 * @see gheConnection
 */
open class GHEConnection() : ProjectFeature() {

    init {
        type = "OAuthProvider"
        param("providerType", "GHE")
        param("defaultTokenScope", "public_repo,repo,repo:status,write:repo_hook")
    }

    constructor(init: GHEConnection.() -> Unit): this() {
        init()
    }

    /**
     * Human friendly connection name
     */
    var displayName by stringParameter()

    /**
     * URL to GitHub Enterprise server
     */
    var serverUrl by stringParameter("gitHubUrl")

    /**
     * OAuth connection client id
     */
    var clientId by stringParameter()

    /**
     * OAuth connection client secret
     */
    var clientSecret by stringParameter("secure:clientSecret")

    /**
     * If <code>true</code>, TeamCity adds a unique value to the callback URL, preventing your access token from being intercepted during a mix-up attack.
     * The final callback URL is displayed inside a corresponding section of connection settings in TeamCity admin UI.
     * The default value is <code>false</code>.
     */
    var useUniqueCallback by booleanParameter("useUniqueRedirect")

    override fun validate(consumer: ErrorConsumer) {
        super.validate(consumer)
        if (displayName == null && !hasParam("displayName")) {
            consumer.consumePropertyError("displayName", "mandatory 'displayName' property is not specified")
        }
        if (clientId == null && !hasParam("clientId")) {
            consumer.consumePropertyError("clientId", "mandatory 'clientId' property is not specified")
        }
        if (clientSecret == null && !hasParam("secure:clientSecret")) {
            consumer.consumePropertyError("clientSecret", "mandatory 'clientSecret' property is not specified")
        }
    }
}


/**
 * Creates a GitHub Enterprise OAuth connection in the current project
 *
 * **Example.**
 * It is not recommended to store secure values such as the secret directly in the DSL code,
 * see [Managing Tokens](https://www.jetbrains.com/help/teamcity/storing-project-settings-in-version-control.html#Managing+Tokens)
 * section of our documentation.
 * ```
 * gheConnection {
 *   id = "<Connection id>" // arbitrary ID that can be later used to refer to the connection
 *   displayName = "<Connection display name>"
 *   serverUrl = "<GitHub Enterprise server URL>"
 *   clientId = "<OAuth2 application client ID>"
 *   clientSecret = "credentialsJSON:*****"
 *   useUniqueCallback = true // optional, false by default
 * }
 * ```
 *
 *
 * @see GitHubConnection
 */
fun ProjectFeatures.gheConnection(init: GHEConnection.() -> Unit): GHEConnection {
    val result = GHEConnection(init)
    feature(result)
    return result
}
